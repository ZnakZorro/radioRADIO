#!/usr/local/bin/node
"use strict";

const express  = require("/usr/local/lib/node_modules/express");
const execSync = require("child_process").execSync;
const https = require('https');
const fs = require('fs');
const port = 8080;
const app = express();
const startPage = "/public/";

const options = {
  key: fs.readFileSync('/home/pi/app/https/privateKey.key'),
  cert: fs.readFileSync('/home/pi/app/https/certificate.crt')
};

https.createServer(options, app).listen(port);

app.use(express.static(__dirname + startPage));

Buffer.prototype.pars = function() {return this.toString().trim();};


	function sendInfo(res,ret){
		//var j = JSON.stringify([ret]);
		res.setHeader("Access-Control-Allow-Origin", "*");
		res.setHeader("Access-Control-Allow-Methods", "*");
		res.setHeader("Access-Control-Allow-Headers", "*");
		res.header('Content-type', 'text/html');
		res.send('<html><head><style>body{font:normal 14px verdana}</style></head><body>'+ret+'</body></html>');
		console.log('#31 sendInfo=',ret);
		console.log('---');
		//res.end(ret);
		return;
	}	

app.get('/', function (req, res) {
  res.header('Content-type', 'text/html');
  return res.end('Hello World!');
});

app.get('/radio/*', function (req, res) {
	let param=req.params[0];
	console.log('#42 radio param=',param);
	let mpcexe = "mpc play";
	if (param) mpcexe += " "+param;
		try {
			var info = execSync(mpcexe).pars();
		} catch(err) {
			var info = err.stderr.toString();
		}
	sendInfo(res,info);
	return;
	/*
	let html = fs.readFileSync(__dirname + startPage+'/index.html').toString();
	html = html.replace("<!--{{}}-->",'Play: '+param+' :: '+info);
	res.header('Content-type', 'text/html');
	html = info;
	return res.end(html);
	*/ 
});

var actualPlaylist = null;

app.get("/folder/*", function(req, res){
	var param=req.params[0];
	console.log('#65 folder param=',param);
	var command = [];
	if (param) {
		actualPlaylist = param;
		command.push("mpc stop");
		command.push("mpc clear");
		command.push("mpc load "+param);
		command.push("mpc play 1");
	}
	var info ="";
	if (command[0]) info = execSync(command[0]).pars();
	if (command[1]) info = execSync(command[1]).pars();
	if (command[2]) info = execSync(command[2]).pars();
	if (command[3]) info = execSync(command[3]).pars();
	return sendInfo(res,info);/*
	let html = fs.readFileSync(__dirname + startPage+'/index.html').toString();
	html = html.replace("<!--{{}}-->",'Play: '+param+' :: '+info);
	res.header('Content-type', 'text/html');
	html = info;
	return res.end(html);*/
});

app.get("/vol/*", function(req, res){
	var param=req.params[0];
	console.log('#89 vol param=',param);
	var info=execSync("mpc volume "+param).pars();
	return sendInfo(res,info);/*
	let html = fs.readFileSync(__dirname + startPage+'/index.html').toString();
	html = html.replace("<!--{{}}-->",'Play: '+param+' :: '+info);
	res.header('Content-type', 'text/html');
	html = info;
	return res.end(html);*/
});
app.get("/next", function(req, res){return sendInfo(res,(execSync("mpc next").pars()));});
app.get("/prev", function(req, res){return sendInfo(res,(execSync("mpc prev").pars()));});

console.log("listening to port "+port);








//var http = require('http');
/*
var express  = require("/usr/local/lib/node_modules/express");
var execSync = require("child_process").execSync;

var https = require('https');

https.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write('Hello World!');
  res.end();
}).listen(8080,function(){console.log(8080)});
*/


/*
var https = require('https');
var fs = require('fs');
 
var options = {
  key: fs.readFileSync('privateKey.key'),
  cert: fs.readFileSync('certificate.crt')
};
 
https.createServer(options, function (req, res) {
  res.writeHead(200);
  res.end("hello world!");
}).listen(8080);
 
console.log("listening to port 8080");

*/
